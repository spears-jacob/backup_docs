#!/bin/bash

if [ $# -lt 2 ] || [ $# -gt 2 ] || [ -z "${1}" ] || [ -z "${2}" ] ; then
    echo "

    Input Format should read: rosetta_build.sh <domain> <project_title>

    Shell script will conclude if these requirements are not met

      "
    exit 1
fi

domain=${1}
project_title=${2}

#parameter validation



echo "
#####--   PRE-PYTHON PROCESSING FILE PREPARATION IN SHELL   --#####
"

#Move files to correct directories based on project_title parameter

echo "
#####--   Build parameterized active project file directories using domain: '$project_domain' and project: '$project_title'   --#####
"

mv bin/$project_title/bin/granular_metrics.tsv bin/granular_metrics.tsv
mv bin/$project_title/bin/qb_input_parameters.csv bin/qb_input_parameters.csv
mv bin/$project_title/hql_templates/* bin/hql_templates
mv bin/$project_title/metric_repo/* bin/metric_repo

# query builder input parameters specifices runs for the query builder
qbipf=bin/qb_input_parameters.csv
# Alias for domain_mappings lookup these are joined to the sourceNames in the qbipf
dmf=bin/domain_mapping.csv

#Sort and strip definitions.tsv to prepare for processing
echo "
#####--   Strip double-quotes from granular_metrics.tsv   --#####
"
sed -i '' 's/\"//g' bin/granular_metrics.tsv

echo "
#####--   Strip trailing tabs from granular_metrics.tsv   --#####
"
sed -i '' -e 's/[[:space:]]*$//' bin/granular_metrics.tsv

echo "
#####--   Sort to correct sort-order for granular_metrics.tsv   --#####
"
(head -n 1 bin/granular_metrics.tsv && tail -n +2 bin/granular_metrics.tsv  | sort -k2,2 -k3,3) > bin/granular_metrics_sorted.tsv
rm -f 'bin/granular_metrics.tsv'
mv bin/granular_metrics_sorted.tsv bin/granular_metrics.tsv

echo "
#####--   Group granular_metrics.tsv on hive_metric   --#####
"
(awk '{ print $2 }' bin/granular_metrics.tsv) > bin/metric_repo/definitions_grouped.tsv

echo "
#####--   Create unique list of hive_metric   --#####
"
echo -e "hive_metric" > bin/metric_repo/metric_unique_list.tsv && (sed 1d bin/metric_repo/definitions_grouped.tsv | uniq) >> bin/metric_repo/metric_unique_list.tsv

echo "
#####--   Create list of only single-row hive_metric   --#####
"
echo -e "hive_metric" > bin/metric_repo/metrics_singles_list.tsv && (sed 1d bin/metric_repo/definitions_grouped.tsv | uniq -u) >> bin/metric_repo/metrics_singles_list.tsv

echo "
#####--   Create list of multi-row hive_metric   --#####
"
echo -e "hive_metric" > bin/metric_repo/metrics_squash_list.tsv && (sed 1d bin/metric_repo/definitions_grouped.tsv | uniq -d) >> bin/metric_repo/metrics_squash_list.tsv

echo "
#####--   Create unique list of multi-row hive_metric   --#####
"
echo -e "hive_metric" > bin/metric_repo/metrics_squash_list_unique.tsv && (sed 1d bin/metric_repo/metrics_squash_list.tsv | uniq) >> bin/metric_repo/metrics_squash_list_unique.tsv

echo "
#####--   RUN PYTHON SCRIPT   --#####
"
python3 bin/build_combined_definitions.py $qbipf $dmf

echo "
#####--   POST-PYTHON PROCESSING FILE CONSOLIDATION IN SHELL   --#####
"

echo "
#####--   Combine HQL Files   --#####
"

group_init=init
group_00=metric_agg
group_01=set_agg_accounts
group_02=set_agg_devices
group_03=set_agg_instances
group_04=set_agg_visits

echo "
#####--   Trim trailing commas from $domain $group_01 files   --#####
"
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_01.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_01_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_01.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_01_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_01.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_02.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_02_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_02.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_02_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_02.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_03.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_03_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_03.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_03_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01'_03.hql'

echo "
#####--   Trim trailing commas from $domain $group_02 files   --#####
"
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_01.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_01_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_01.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_01_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_01.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_02.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_02_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_02.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_02_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_02.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_03.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_03_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_03.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_03_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02'_03.hql'

echo "
#####--   Trim trailing commas from $domain $group_03 files   --#####
"
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_01.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_01_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_01.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_01_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_01.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_02.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_02_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_02.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_02_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_02.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_03.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_03_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_03.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_03_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03'_03.hql'

echo "
#####--   Trim trailing commas from $domain $group_04 files   --#####
"
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_01.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_01_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_01.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_01_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_01.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_02.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_02_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_02.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_02_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_02.hql'
sed '$ s/.$//' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_03.hql'  > '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_03_trimmed.hql'
rm '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_03.hql'; mv '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_03_trimmed.hql' '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04'_03.hql'

echo "
#####--   ${group_init}   --#####
"
rm -f '../../extract/parameterized/'$domain'_'$project_title'_metric_agg/src/init/'$domain'_'$project_title'_create_tables_and_views.hql'
touch '../../extract/parameterized/'$domain'_'$project_title'_metric_agg/src/init/'$domain'_'$project_title'_create_tables_and_views.hql'
cat '../temp_file_dump/temp_files/'$domain'_'$project_title'_create_tables_and_views'*'.hql' >> '../../extract/parameterized/'$domain'_'$project_title'_metric_agg/src/init/'$domain'_'$project_title'_create_tables_and_views.hql'

echo "
#####--   ${group_00}   --#####
"
rm -f '../../extract/parameterized/'$domain'_'$project_title'_metric_agg/src/'$domain'_'$project_title'_'$group_00'.hql'
touch '../../extract/parameterized/'$domain'_'$project_title'_metric_agg/src/'$domain'_'$project_title'_'$group_00'.hql'
cat '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_00''*'.hql' >> '../../extract/parameterized/'$domain'_'$project_title'_metric_agg/src/'$domain'_'$project_title'_'$group_00'.hql'

echo "
#####--   ${group_01}   --#####
"
rm -f '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_01'.hql'
touch '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_01'.hql'
cat '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_01''*'.hql' >> '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_01'.hql'

echo "
#####--   ${group_02}   --#####
"
rm -f '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_02'.hql'
touch '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_02'.hql'
cat '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_02''*'.hql' >> '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_02'.hql'

echo "
#####--   ${group_03}   --#####
"
rm -f '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_03'.hql'
touch '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_03'.hql'
cat '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_03''*'.hql' >> '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_03'.hql'

echo "
#####--   ${group_04}   --#####
"
rm -f '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_04'.hql'
touch '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_04'.hql'
cat '../temp_file_dump/temp_files/'$domain'_'$project_title'_'$group_04''*'.hql' >> '../../extract/parameterized/'$domain'_'$project_title'_set_aggs/src/'$domain'_'$project_title'_'$group_04'.hql'



echo "
#####--   Return active project file directories to source folders   --#####
"

mv bin/granular_metrics.tsv bin/$project_title/bin/granular_metrics.tsv
mv bin/qb_input_parameters.csv bin/$project_title/bin/qb_input_parameters.csv
mv bin/hql_templates/* bin/$project_title/hql_templates
mv bin/metric_repo/* bin/$project_title/metric_repo
rm ../temp_file_dump/temp_files/*
